# Welcome

Welcome is a splash screen that displays some info about the app and directs the user to log in our create an account.
